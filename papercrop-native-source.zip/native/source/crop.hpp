#pragma once
#include <opencv2/opencv.hpp>
#include <algorithm>
#include <array>
#include <cmath>
#include <stdexcept>

namespace papercrop {
// Work with the outer envelope. Dark print or clothing can create deep notches
// in a brightness mask even though the physical photo is rectangular.
inline std::vector<cv::Point2f> corners(const cv::Mat &mask, double minimumArea,
                                        cv::Rect *bounds = nullptr) {
    std::vector<std::vector<cv::Point>> contours;
    cv::findContours(mask, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
    std::sort(contours.begin(), contours.end(),
              [](const auto &a, const auto &b) { return cv::contourArea(a) > cv::contourArea(b); });
    for (const auto &c : contours) {
        double area = cv::contourArea(c);
        if (area < minimumArea)
            break;
        auto box = cv::minAreaRect(c);
        if (std::min(box.size.width, box.size.height) < 8)
            continue;
        std::vector<cv::Point> hull;
        cv::convexHull(c, hull);
        double hullArea = cv::contourArea(hull);
        if (area < hullArea * 0.55)
            continue;
        for (double epsilon : {0.01, 0.015, 0.02, 0.03}) {
            std::vector<cv::Point> p;
            cv::approxPolyDP(hull, p, epsilon * cv::arcLength(hull, true), true);
            if (p.size() == 4 && cv::isContourConvex(p) && cv::contourArea(p) > hullArea * 0.9) {
                if (bounds)
                    *bounds = cv::boundingRect(c);
                std::vector<cv::Point2f> result;
                for (auto v : p)
                    result.emplace_back(float(v.x), float(v.y));
                return result;
            }
        }
    }
    return {};
}
inline cv::Mat brightness(const cv::Mat &image) {
    std::vector<cv::Mat> channels;
    cv::split(image, channels);
    cv::Mat result;
    cv::max(channels[0], channels[1], result);
    cv::max(result, channels[2], result);
    return result;
}
inline void cleanMask(cv::Mat &mask) {
    // Scanner frame streaks can touch a document. Remove thin attachments
    // before fitting the envelope; never erase pixels in the source image.
    cv::morphologyEx(mask, mask, cv::MORPH_OPEN, cv::getStructuringElement(cv::MORPH_RECT, {5, 5}),
                     {-1, -1}, 1, cv::BORDER_CONSTANT, cv::Scalar(0));
    cv::morphologyEx(mask, mask, cv::MORPH_CLOSE,
                     cv::getStructuringElement(cv::MORPH_RECT, {3, 3}));
}
} // namespace papercrop

// Geometry is measured at reduced resolution; all output pixels come from src.
inline cv::Mat cropPaper(const cv::Mat &src, int width = 0, int height = 0,
                         bool perspective = false) {
    if (src.empty())
        throw std::runtime_error("Cannot decode image");
    double scale = std::min(1.0, 1600.0 / std::max(src.cols, src.rows));
    cv::Mat small, gray, mask;
    cv::resize(src, small, cv::Size(), scale, scale, cv::INTER_AREA);
    // Estimate black scanner noise from the frame. Use the strongest color
    // channel so saturated blue/red photo content is not mistaken for black.
    cv::Mat light = papercrop::brightness(small);
    std::array<int, 256> histogram{};
    int count = 0;
    for (int y = 0; y < light.rows; ++y)
        for (int x = 0; x < light.cols; ++x)
            if (y == 0 || x == 0 || y == light.rows - 1 || x == light.cols - 1) {
                ++histogram[light.at<uchar>(y, x)];
                ++count;
            }
    int cumulative = 0, background = 0;
    for (; background < 255; ++background) {
        cumulative += histogram[background];
        if (cumulative >= count / 2)
            break;
    }
    std::vector<cv::Point2f> corners;
    cv::Rect sourceBounds, workingBounds;
    auto mapBounds = [&](cv::Rect box) {
        double sx = double(src.cols) / small.cols, sy = double(src.rows) / small.rows;
        int x = int(std::floor(box.x * sx)), y = int(std::floor(box.y * sy));
        return cv::Rect(x, y, int(std::ceil((box.x + box.width) * sx)) - x,
                        int(std::ceil((box.y + box.height) * sy)) - y) &
               cv::Rect(0, 0, src.cols, src.rows);
    };
    bool darkBackground = background <= 40;
    int blackCutoff = std::max(12, background + 12);
    double minimumArea = std::max(64.0, light.total() * 0.0005);
    if (darkBackground) {
        cv::threshold(light, mask, blackCutoff, 255, cv::THRESH_BINARY);
        papercrop::cleanMask(mask);
        corners = papercrop::corners(mask, minimumArea, &workingBounds);
        // Refine in the original-resolution neighborhood: small photos should
        // not lose border pixels through downsampling and rounding.
        if (!corners.empty()) {
            sourceBounds = mapBounds(workingBounds);
            for (auto &p : corners) {
                p.x *= float(src.cols) / small.cols;
                p.y *= float(src.rows) / small.rows;
            }
            cv::Rect roi = sourceBounds;
            int padding = int(std::ceil(5.0 / scale));
            roi.x -= padding;
            roi.y -= padding;
            roi.width += 2 * padding;
            roi.height += 2 * padding;
            roi &= cv::Rect(0, 0, src.cols, src.rows);
            // Bound refinement memory for high-resolution A3 scans.
            if (roi.area() <= 4000000) {
                cv::Mat refined;
                cv::threshold(papercrop::brightness(src(roi)), refined, blackCutoff, 255,
                              cv::THRESH_BINARY);
                papercrop::cleanMask(refined);
                cv::Rect refinedBounds;
                auto precise =
                    papercrop::corners(refined, minimumArea / (scale * scale), &refinedBounds);
                if (!precise.empty()) {
                    corners = std::move(precise);
                    sourceBounds = refinedBounds + roi.tl();
                    for (auto &p : corners) {
                        p.x += roi.x;
                        p.y += roi.y;
                    }
                }
            }
        }
    }
    if (corners.empty()) {
        cv::cvtColor(small, gray, cv::COLOR_BGR2GRAY);
        cv::GaussianBlur(gray, gray, cv::Size(5, 5), 0);
        cv::threshold(gray, mask, 0, 255, cv::THRESH_BINARY | cv::THRESH_OTSU);
        papercrop::cleanMask(mask);
        corners = papercrop::corners(mask, minimumArea, &workingBounds);
        if (!corners.empty())
            sourceBounds = mapBounds(workingBounds);
        for (auto &p : corners) {
            p.x *= float(src.cols) / small.cols;
            p.y *= float(src.rows) / small.rows;
        }
    }
    if (corners.empty())
        throw std::runtime_error("No clear four-sided object found against the background");
    cv::Point2f center(0, 0);
    for (auto p : corners)
        center += p * 0.25f;
    std::sort(corners.begin(), corners.end(), [&](auto a, auto b) {
        return std::atan2(a.y - center.y, a.x - center.x) <
               std::atan2(b.y - center.y, b.x - center.x);
    });
    auto first = std::min_element(corners.begin(), corners.end(),
                                  [](auto a, auto b) { return a.x + a.y < b.x + b.y; });
    std::rotate(corners.begin(), first, corners.end());
    int w = 1 + std::lround(
                    std::max(cv::norm(corners[1] - corners[0]), cv::norm(corners[2] - corners[3])));
    int h = 1 + std::lround(
                    std::max(cv::norm(corners[3] - corners[0]), cv::norm(corners[2] - corners[1])));
    if (!perspective) {
        w = sourceBounds.width;
        h = sourceBounds.height;
    }
    if (w < 32 || h < 32)
        throw std::runtime_error("Detected paper is too small");
    // Warp straight to final resolution so pixels are interpolated only once.
    int outW = w, outH = h;
    if (width || height) {
        double factor = width && height ? std::min(double(width) / w, double(height) / h)
                        : width         ? double(width) / w
                                        : double(height) / h;
        outW = std::max(1, int(std::lround(w * factor)));
        outH = std::max(1, int(std::lround(h * factor)));
    }
    std::vector<cv::Point2f> dst = {
        {0, 0}, {float(outW - 1), 0}, {float(outW - 1), float(outH - 1)}, {0, float(outH - 1)}};
    cv::Mat result;
    if (perspective)
        cv::warpPerspective(src, result, cv::getPerspectiveTransform(corners, dst), {outW, outH},
                            cv::INTER_LINEAR, cv::BORDER_REPLICATE);
    else if (outW == sourceBounds.width && outH == sourceBounds.height)
        result = src(sourceBounds).clone();
    else
        cv::resize(src(sourceBounds), result, {outW, outH}, 0, 0,
                   outW < sourceBounds.width ? cv::INTER_AREA : cv::INTER_LINEAR);
    if (width && height) {
        cv::Mat canvas(height, width, src.type(), cv::Scalar::all(255));
        result.copyTo(canvas(cv::Rect((width - outW) / 2, (height - outH) / 2, outW, outH)));
        return canvas;
    }
    return result;
}
