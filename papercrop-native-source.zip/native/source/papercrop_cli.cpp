// Native processing engine for the existing Python/PySide6 frontend.
// All pixel-level image work is performed in C++/OpenCV.
// The crop algorithm is PaperCrop 2.3 (crop.hpp) with its original behavior.
#include "crop.hpp"
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <algorithm>
#include <cmath>
#include <cctype>
#include <iterator>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
#ifdef _WIN32
#include <windows.h>
#include <shellapi.h>
#endif

namespace fs = std::filesystem;

static fs::path utf8path(const std::string &s) {
    return fs::u8path(s);
}
static std::vector<std::string> getArgs(int argc, char **argv) {
#ifdef _WIN32
    int count = 0;
    LPWSTR *wide = CommandLineToArgvW(GetCommandLineW(), &count);
    if (!wide) throw std::runtime_error("CommandLineToArgvW failed");
    std::vector<std::string> result;
    for (int i = 0; i < count; ++i) {
        int bytes = WideCharToMultiByte(CP_UTF8, 0, wide[i], -1, nullptr, 0, nullptr, nullptr);
        if (bytes <= 0) { LocalFree(wide); throw std::runtime_error("UTF-8 conversion failed"); }
        std::string s(static_cast<size_t>(bytes), '\0');
        WideCharToMultiByte(CP_UTF8, 0, wide[i], -1, s.data(), bytes, nullptr, nullptr);
        s.pop_back();
        result.push_back(std::move(s));
    }
    LocalFree(wide);
    return result;
#else
    return {argv, argv + argc};
#endif
}
static std::string opt(const std::vector<std::string> &args, const std::string &name,
                       const std::string &fallback = "") {
    for (size_t i = 1; i < args.size(); ++i) {
        if (args[i] == name) {
            if (i + 1 >= args.size()) throw std::runtime_error("Missing value for " + name);
            return args[i + 1];
        }
    }
    return fallback;
}
static int intOpt(const std::vector<std::string> &args, const std::string &name, int fallback) {
    std::string value = opt(args, name, std::to_string(fallback));
    size_t used = 0;
    int n = std::stoi(value, &used);
    if (used != value.size() || n < 0 || n > 12000)
        throw std::runtime_error("Invalid " + name + ": expected 0..12000");
    return n;
}
static cv::Mat loadImage(const fs::path &path) {
    std::ifstream stream(path, std::ios::binary);
    if (!stream) throw std::runtime_error("Cannot open input image");
    std::vector<uchar> bytes((std::istreambuf_iterator<char>(stream)),
                              std::istreambuf_iterator<char>());
    if (bytes.empty()) throw std::runtime_error("Input image is empty");
    cv::Mat result = cv::imdecode(bytes, cv::IMREAD_COLOR);
    if (result.empty()) throw std::runtime_error("Cannot decode input image");
    return result;
}
static void saveImage(const fs::path &path, const cv::Mat &image) {
    if (image.empty()) throw std::runtime_error("Cannot save empty image");
    std::string ext = path.extension().string();
    std::transform(ext.begin(), ext.end(), ext.begin(), [](unsigned char c) {return char(std::tolower(c));});
    if (ext != ".jpg" && ext != ".jpeg" && ext != ".png" && ext != ".bmp" && ext != ".tif" && ext != ".tiff")
        throw std::runtime_error("Unsupported output image extension");
    std::vector<uchar> encoded;
    std::vector<int> params;
    if (ext == ".jpg" || ext == ".jpeg") params = {cv::IMWRITE_JPEG_QUALITY, 95};
    if (!cv::imencode(ext, image, encoded, params))
        throw std::runtime_error("Could not encode output image");
    fs::create_directories(path.parent_path());
    // Write a sibling temporary file and only publish on complete write.
    // The Python service supplies a unique output path.
    fs::path temp = path;
    temp += ".writing";
    try {
        std::ofstream f(temp, std::ios::binary | std::ios::trunc);
        if (!f) throw std::runtime_error("Cannot open output file");
        f.write(reinterpret_cast<const char *>(encoded.data()), std::streamsize(encoded.size()));
        f.close();
        if (!f) throw std::runtime_error("Failed writing output file");
        // We refuse to overwrite a previously produced result.
        if (fs::exists(path)) throw std::runtime_error("Output file already exists");
        fs::rename(temp, path);
    } catch (...) {
        std::error_code ignore;
        fs::remove(temp, ignore);
        throw;
    }
}
static cv::Mat resizeMax(const cv::Mat &image, int maxW, int maxH) {
    if (maxW == 0 || maxH == 0) return image;
    if (image.cols <= maxW && image.rows <= maxH) return image;
    double factor = std::min(double(maxW) / image.cols, double(maxH) / image.rows);
    int w = std::max(1, int(std::lround(image.cols * factor)));
    int h = std::max(1, int(std::lround(image.rows * factor)));
    cv::Mat out;
    cv::resize(image, out, cv::Size(w, h), 0, 0, cv::INTER_AREA);
    return out;
}
static cv::Mat combineVertical(const cv::Mat &top, const cv::Mat &bottom) {
    int width = std::max(top.cols, bottom.cols);
    int height = top.rows + bottom.rows;
    cv::Mat output(height, width, CV_8UC3, cv::Scalar::all(255));
    top.copyTo(output(cv::Rect(0, 0, top.cols, top.rows)));
    bottom.copyTo(output(cv::Rect(0, top.rows, bottom.cols, bottom.rows)));
    return output;
}
static int execute(const std::vector<std::string> &args) {
    if (args.size() < 2 || (args[1] != "crop" && args[1] != "resize" && args[1] != "combine"))
        throw std::runtime_error("Usage: papercrop_cli crop|resize|combine --input PATH --output PATH [options]");
    const auto input = opt(args, "--input");
    const auto output = opt(args, "--output");
    if (input.empty() || output.empty()) throw std::runtime_error("--input and --output are required");
    cv::Mat processed = loadImage(utf8path(input));
    int maxW = intOpt(args, "--max-width", 0);
    int maxH = intOpt(args, "--max-height", 0);
    if (args[1] == "crop") {
        int width = intOpt(args, "--width", 0);
        int height = intOpt(args, "--height", 0);
        bool perspective = intOpt(args, "--perspective", 0) != 0;
        processed = cropPaper(processed, width, height, perspective);
        processed = resizeMax(processed, maxW, maxH);
    } else if (args[1] == "resize") {
        processed = resizeMax(processed, maxW, maxH);
    } else {
        const auto second = opt(args, "--second");
        if (second.empty()) throw std::runtime_error("--second is required for combine");
        processed = combineVertical(processed, loadImage(utf8path(second)));
        processed = resizeMax(processed, maxW, maxH);
    }
    saveImage(utf8path(output), processed);
    std::cout << "OK " << processed.cols << "x" << processed.rows << "\n";
    return 0;
}
int main(int argc, char **argv) {
    try {
        return execute(getArgs(argc, argv));
    } catch (const cv::Exception &ex) {
        std::cerr << "OpenCV processing error: " << ex.what() << "\n";
        return 2;
    } catch (const std::exception &ex) {
        std::cerr << "Processing error: " << ex.what() << "\n";
        return 2;
    }
}
